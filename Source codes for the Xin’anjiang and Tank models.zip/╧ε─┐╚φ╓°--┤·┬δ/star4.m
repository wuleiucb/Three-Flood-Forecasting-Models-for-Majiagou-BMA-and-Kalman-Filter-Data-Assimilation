function varargout = star4(varargin)
% STAR4 MATLAB code for star4.fig
%      STAR4, by itself, creates a new STAR4 or raises the existing
%      singleton*.
%
%      H = STAR4 returns the handle to a new STAR4 or the handle to
%      the existing singleton*.
%
%      STAR4('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in STAR4.M with the given input arguments.
%
%      STAR4('Property','Value',...) creates a new STAR4 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before star4_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to star4_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help star4

% Last Modified by GUIDE v2.5 28-Sep-2022 17:28:19

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @star4_OpeningFcn, ...
                   'gui_OutputFcn',  @star4_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before star4 is made visible.
function star4_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to star4 (see VARARGIN)

% Choose default command line output for star4
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes star4 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = star4_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
selection=questdlg(['ȷ���˳���'],['�˳���ϵͳ'],'��','��','������һ��','ȡ��');
if strcmp(selection,'��')
    return;
end
if strcmp(selection,'������һ��')
    star2;
    delete(gcbf);
end
if strcmp(selection,'��')
    delete(gcf);
end

% --- Executes during object creation, after setting all properties.
function axes1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes1

% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% ��������
global Flood20200803;
data1=Flood20200803;
% data1=cell2mat(struct2cell(load('Flood20200803.mat')));
time(:,1)=[1 length(data1)];
time(:,2)=[1 length(data1)];
global caldata valdata data
hangcal=find(data1(:,1)>=time(1,1)&data1(:,1)<=time(2,1)); 
hangval=find(data1(:,1)>=time(1,2)&data1(:,1)<=time(2,2));
data=data1;
caldata=data1(hangcal,:);
valdata=data1(hangval,:);
global opx;
[fit,dc,result,tt]=XAJ_run_rz(opx);
QB =result(:,1);
QZ = result(:,3);
Q = result(:,4);
% fig = figure;
% left_color = [0 0 0];
% right_color = [0 0 0];
% set(fig,'defaultAxesColorOrder',[left_color; right_color]);
yyaxis left
plot(QZ,'k', 'LineWidth',2, 'MarkerSize',1, 'MarkerEdgeColor', 'k', 'MarkerFaceColor','c');   
hold on
plot(Q,'r--o', 'LineWidth',2, 'MarkerSize',1, 'MarkerEdgeColor', 'r', 'MarkerFaceColor','r');
hold on
ylabel('���� / (m^3/s) ')
axis([data1(1,1) data1(end,1) 0 1500]);
yyaxis right
% plot(QB);
bar1(:,1) = QB;
GO = bar(bar1,1,'EdgeColor','black');
GO(1).FaceColor = [148/255,166/255,196/255];
% plot(QB,'m--^', 'LineWidth',2, 'MarkerSize',1, 'MarkerEdgeColor', 'k', 'MarkerFaceColor','r');
h = gca; % Handle to currently active axes
set(h,'YDir','reverse','FontSize',12); 
ylabel('������ / mm')
xlabel('ʱ������ / h')
legend('   ʵ������ ', '   XAJģ������ ', '   ������ ','location','East','FontSize',14);
title('�°���ģ��ģ�⡪��Result of 20200803','FontSize',18,'Color','b')
axis([data1(1,1) data1(end,1) 0 15]);
grid on
