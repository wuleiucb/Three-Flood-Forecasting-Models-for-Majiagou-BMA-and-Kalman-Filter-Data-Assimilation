function [fit,dc,result,tt]=XAJ_run2(XX)
global caldata valdata data
tt=[];
AREA=1311;
warmdays=0;
N=1;  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
nt=size(caldata,1);
P=caldata(:,2);  
EM=caldata(:,3);  
QS=caldata(:,4); 
TRSS0=0.3*QS(1); 
TRG0=0.4*QS(1);
[num,numvars]=size(XX); 
dcc=[];
for I=1:num     
K=XX(I,1);
SM=XX(I,2);
KG=XX(I,3); 
KSS=XX(I,4); 
KKG=XX(I,5); 
KKSS=XX(I,6);
CS=XX(I,7);
WUM=XX(I,8);
WLM=XX(I,9);
WDM=XX(I,10);
WM=WUM+WLM+WDM;
IMP=XX(I,11); 
B=XX(I,12);
C=XX(I,13);
EX=XX(I,14);
CR=XX(I,15); 
% ------------------
L=XX(I,16);
L=round(L);

WU=0.5*WUM;WL=0.5*WLM;WD=0.5*WDM;  
W=WU+WL+WD;   
wt(1,:)=[WU WL WD W];
S=0.1*SM;   
%------------------
WMM=(1+B)*WM/(1-IMP);  
FR=0.5; 
PE=P-K*EM;  
U=AREA/3.6/N;   
for T=1:nt              
    if PE(T)<0
        R=0; 
    else
        % ����Aֵ
        if  W>=WM
            A=WMM; 
        else
            A=WMM*(1-(1-W/WM)^(1/(1+B)));  
        end
        if A+PE(T)>0
            if A+PE(T)<WMM
                R=PE(T)-WM+W+WM*(1-(PE(T)+A)/WMM)^(1+B);  
            else
                R=PE(T)+W-WM;
            end
        else
            R=0;
        end
    end
    if R<0,R=0;end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
    if PE(T)<0   % ��������С��������ʱʱ,�޲���R
        if WU+PE(T)>0
            EU=K*EM(T);   
            ED=0;
            EL=0;
            WU=WU+PE(T);
        else              
            EU=WU+P(T);
            WU=0;
            if WL>C*WLM  
                EL=(K*EM(T)-EU)*WL/WLM; 
                WL=WL-EL;
                ED=0;
            else
                if WL>C*(K*EM(T)-EU)  
                    EL=C*(K*EM(T)-EU);
                    WL=WL-EL;
                    ED=0;
                else
                    EL=WL;
                    WL=0;
                    ED=C*(K*EM(T)-EU)-EL;
                    WD=WD-ED;
                end
            end
        end
    else  % ������������������ʱʱ,�в���R   ��P+WU >= Epʱ
        EU=K.*EM(T); 
        ED=0;
        EL=0;
        if WU+PE(T)-R<WUM
            WU=WU+PE(T)-R;
        else 
            if WU+WL+PE(T)-WUM>WLM
                WU=WUM;
                WL=WLM;
                WD=W+PE(T)-R-WU-WL;
            else
                WL=WU+WL+PE(T)-R-WUM;
                WU=WUM;
            end
        end
    end
    E(T,1)=EU+EL+ED;
    W=WU+WL+WD; 
    
    wt(T+1,:)=[WU WL WD W];
    % ����Ϊ��ˮԴ��ˮ����%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    SMM=(1+EX)*SM;  
    if (PE(T)<=0) || (R<=0)  %������ʱ
        RS=0;    
        RG=S*KG*FR;    
        RSS=RG*KSS/KG;   
        S=S-(RG+RSS)/FR;
        if S>SM,S=SM;end
        if S<0,S=0.00001;end
    else
        X=FR;  
        FR=(R-PE(T)*IMP)/PE(T);   
        if FR<=0,FR=0.001;end
        S=X*S/FR; 
        if S>SM,S=SM;end
        if S<0,S=0.00001;end
        SS=S;
        Q=R/FR;
        G=fix(Q/5)+1; 
        Q=Q/G;
        KSSD=(1.0 -(1.0 -(KG+KSS))^(1/G))/(1+KG/KSS);
        KGD=KSSD*KG/KSS;
        RS=0;
        RG=0;
        RSS=0;
        for J=1:G
            if S>SM,S=SM;end
            if S<0,S=0.00001;end
            AU=SMM*(1-(1-S/SM)^(1/(1+EX))); 
            if AU+Q<SMM
                RS=(Q-SM+S+SM*(1-(Q+AU)/SMM)^(1+EX))*FR+RS;
            else
                RS=(Q+S-SM)*FR+RS;
            end
            S=J*Q-RS/FR+S;
            RG=S*KGD*FR+RG;
            RSS=S*KSSD*FR+RSS;
            S=J*Q+SS-(RS+RSS+RG)/FR;
            if S>SM,S=SM;end
            if S<0,S=0.00001;end
        end
    end
    OUT(T,:)=[RS,RSS,RG,R]; 
end    
%����Ϊ��������%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
RS=OUT(:,1); RSS=OUT(:,2);RG=OUT(:,3);
TRS(1)=RS(1)*U;  
TRSS(1)=TRSS0 ;   
TRG(1)=TRG0 ;    
TR(1)=TRS(1)+TRSS(1)+TRG(1);
for T=2:nt
    TRS(T)=TRS(T-1)*CS+ RS(T)*(1-CS)*U;  
    TRSS(T)=TRSS(T-1)*KKSS+RSS(T)*(1-KKSS)*U;  
    TRG(T)=TRG(T-1)*KKG+RG(T)*(1-KKG)*U;      
    TR(T)=TRS(T)+TRSS(T)+TRG(T);   
end
TRR=[TRS' TRSS' TRG'];
QJ=TR';   
for T=L+2:nt
    QJ(T)=CR*QJ(T-1)+(1-CR)*TR(T-L);   
end
QS1=QS(warmdays+1:end); 
QJ1=QJ(warmdays+1:end);
f1=sum((QS1-QJ1).^2);
f2=sum((QS1-mean(QS1)).^2);
dc(I)=1-f1/f2;
 if dc(I)<0
     dc(I)=-dc(I); 
 else
    dc(I)= dc(I);
 end
w=length(QJ1);
for i=1:w  
    if i>4
            e(i-4,1)=QS1(i-1)-QJ1(i-1);
            et(i-4,1)=QS1(i-4)-QJ1(i-4);
            c = (e.'*e)^ - 1*e.'*et;
            QJJ(i,1)=QJ1(i,1)+c*(QS1(i-4)-QJ1(i-4));
    else
            QJJ(i,1)=QJ1(i,1);
    end
  
    if  QJJ(i,1)<0
            QJJ(i,1)=QJ1(i,1);
    end
        i=i+1; 
end
result =[P E QS QJJ];
point=find(QS1>50);
QJJ=QJJ(min(point):max(point));
QS1=QS1(min(point):max(point));

[hf,fxsj]=max(QJJ,[],1);
[hf2,fxsj2]=max(QS1,[],1);
hfpg=abs((hf2-hf)/hf2);
hfpg1=hfpg;
 if hfpg>0.2 
    hfpg=100;   
else
    hfpg=hfpg/0.2;
end  
tt(1)=hfpg1;
fspg=abs(fxsj2-fxsj);
fspg1=fspg;
if fspg>3
    fspg=100;
else
    fspg=fspg/3;
end  
tt(2)=fspg1;
hl=0;
hl2=0;
for n=1:1:length(QJJ)-1
    hl=hl+((QJJ(n)+QJJ(n+1))*3600/2);
    hl2=hl2+((QS1(n)+QS1(n+1))*3600/2);
end
tt(5)=hl;
tt(6)=hl2;
hlpg=abs((hl2-hl)/hl2);
hlpg1=hlpg;
if hlpg>0.2
    hlpg=100;
else
    hlpg=hlpg/0.2;
end  
tt(3)= hlpg1;
nse=-(1-sum((QJJ-QS1).^2)/sum((QS1-mean(QS1)).^2));
tt(4)= abs(nse);
yy=hlpg+fspg+hfpg+nse;
fit(I)=yy;
end
fit=fit'; 
dc=dc';
tt;