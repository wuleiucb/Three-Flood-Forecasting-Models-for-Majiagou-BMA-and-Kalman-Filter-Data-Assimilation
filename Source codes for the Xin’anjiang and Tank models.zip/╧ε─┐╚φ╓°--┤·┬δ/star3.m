function varargout = star3(varargin)
% STAR3 MATLAB code for star3.fig
%      STAR3, by itself, creates a new STAR3 or raises the existing
%      singleton*.
%
%      H = STAR3 returns the handle to a new STAR3 or the handle to
%      the existing singleton*.
%
%      STAR3('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in STAR3.M with the given input arguments.
%
%      STAR3('Property','Value',...) creates a new STAR3 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before star3_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to star3_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help star3

% Last Modified by GUIDE v2.5 28-Sep-2022 10:52:41

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @star3_OpeningFcn, ...
                   'gui_OutputFcn',  @star3_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before star3 is made visible.
function star3_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to star3 (see VARARGIN)

% Choose default command line output for star3
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes star3 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = star3_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
star2;
delete(gcbf); 


% --- Executes during object creation, after setting all properties.
function axes1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Choose default command line output for Star
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
pic_handle=findobj('tag','axes1');   
axes(pic_handle);
logo=imread('xsh.jpg');
image(logo);
set(pic_handle,'visible','off');
% Hint: place code in OpeningFcn to populate axes1
% Hint: place code in OpeningFcn to populate axes1
