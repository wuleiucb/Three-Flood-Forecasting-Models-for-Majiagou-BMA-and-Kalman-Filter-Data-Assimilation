function varargout = star6(varargin)
% STAR6 MATLAB code for star6.fig
%      STAR6, by itself, creates a new STAR6 or raises the existing
%      singleton*.
%
%      H = STAR6 returns the handle to a new STAR6 or the handle to
%      the existing singleton*.
%
%      STAR6('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in STAR6.M with the given input arguments.
%
%      STAR6('Property','Value',...) creates a new STAR6 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before star6_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to star6_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help star6

% Last Modified by GUIDE v2.5 12-Oct-2022 22:25:40

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @star6_OpeningFcn, ...
                   'gui_OutputFcn',  @star6_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before star6 is made visible.
function star6_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to star6 (see VARARGIN)

% Choose default command line output for star6
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes star6 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = star6_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
selection=questdlg(['ȷ���˳���'],['�˳���ϵͳ'],'��','��','������һ��','ȡ��');
if strcmp(selection,'��')
    return;
end
if strcmp(selection,'������һ��')
    star2;
    delete(gcbf);
end
if strcmp(selection,'��')
    delete(gcf);
end


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1
val=get(handles.popupmenu1, 'value');
global testpoint
switch val
    case 1
        testpoint=0;
    case 2
        testpoint=1;
    case 3
        testpoint=2;
    case 4 
        testpoint=3;
    case 5
        testpoint=4;
    case 6
        testpoint=5;
    case 7
        testpoint=6;
    case 8
        testpoint=7;
    case 9
        testpoint=8;
    case 10
        testpoint=9;
end

% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global testpoint;
v=testpoint;
if v==1
    global Flood20190621;
    data1=Flood20190621;
    delete(gcbf); 
    figure( star6);
end
if v==2
    global Flood20190722;
    data1=Flood20190722;
    delete(gcbf); 
    figure( star6);
end
if v==3
    global Flood20190910;
    data1=Flood20190910;
    delete(gcbf); 
    figure( star6);
    end
if v==4
    global Flood20200616;
    data1=Flood20200616;
   delete(gcbf); 
   figure( star6);
end
if v==5
    global Flood20200725;
    data1=Flood20200725;
    delete(gcbf); 
    figure( star6);
end
if v==6
    global Flood20200803;
    data1=Flood20200803;
    delete(gcbf); 
    figure( star6);
end
if v==7
     global Flood20210616;
     data1=Flood20210616;

end
if v==8
    global Flood20210818;
    data1=Flood20210818;
    delete(gcbf); 
    figure( star6);
end
if v==9
    global Flood20210918;
    data1=Flood20210918;
    delete(gcbf); 
    figure( star6);
end    

time(:,1)=[1 length(data1)];
time(:,2)=[1 length(data1)];
global caldata valdata data
hangcal=find(data1(:,1)>=time(1,1)&data1(:,1)<=time(2,1)); % find���ҷ���Ԫ�ص�������ֵ �ʶ���  
hangval=find(data1(:,1)>=time(1,2)&data1(:,1)<=time(2,2)); % ��֤��
data=data1;
caldata=data1(hangcal,:);
valdata=data1(hangval,:);
global opx;
[fit,dc,result,tt]=XAJ_run_rz(opx);
global opx1;
[gare1,result1,tt1]=TANK_run_rz1(opx1);
QB =result(:,1);
QZ = result(:,3);
Q = result(:,4);
tankQ=result1(:,3);
yyaxis left
plot(QZ,'k', 'LineWidth',2, 'MarkerSize',1, 'MarkerEdgeColor', 'k', 'MarkerFaceColor','k');   
hold on
plot(Q,'r--o', 'LineWidth',2, 'MarkerSize',1, 'MarkerEdgeColor', 'r', 'MarkerFaceColor','r');
hold on
plot(tankQ,'g--s', 'LineWidth',2, 'MarkerSize',1, 'MarkerEdgeColor', 'g', 'MarkerFaceColor','g')
ylabel('����/(m^3/s) ')
axis([data1(1,1) data1(end,1) 0 (max(QZ)+500)]);
yyaxis right
bar1(:,1) = QB;
GO = bar(bar1,1,'EdgeColor','black');
GO(1).FaceColor = [148/255,166/255,196/255];
h = gca; 
set(h,'YDir','reverse','FontSize',12); 
ylabel('������/mm')
xlabel('ʱ������/h')

legend('ʵ������ ', 'XAJģ������ ', 'TANKģ������','������','location','East','FontSize',14);
axis([data1(1,1) data1(end,1) 0 15]);
grid on
if v==1
    title('�°�����ˮ��ģ��ģ�����Աȡ���Results of 20190621','FontSize',18,'Color','b')
end
if v==2
    title('�°�����ˮ��ģ��ģ�����Աȡ���Results of 20190722','FontSize',18,'Color','b')
end
if v==3
    title('�°�����ˮ��ģ��ģ�����Աȡ���Results of 20190910','FontSize',18,'Color','b')
end
if v==4
    title('�°�����ˮ��ģ��ģ�����Աȡ���Results of 20200616','FontSize',18,'Color','b')
end
if v==5
    title('�°�����ˮ��ģ��ģ�����Աȡ���Results of 20200725','FontSize',18,'Color','b')
end
if v==6
    title('�°�����ˮ��ģ��ģ�����Աȡ���Results of 20200803','FontSize',18,'Color','b')
end
if v==7
    title('�°�����ˮ��ģ��ģ�����Աȡ���Results of 20210616','FontSize',18,'Color','b')
end
if v==8
    title('�°�����ˮ��ģ��ģ�����Աȡ���Results of 20210818','FontSize',18,'Color','b')
end
if v==9
    title('�°�����ˮ��ģ��ģ�����Աȡ���Results of 20210918','FontSize',18,'Color','b')
end
