function varargout = star2(varargin)
% STAR2 MATLAB code for star2.fig
%      STAR2, by itself, creates a new STAR2 or raises the existing
%      singleton*.
%
%      H = STAR2 returns the handle to a new STAR2 or the handle to
%      the existing singleton*.
%
%      STAR2('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in STAR2.M with the given input arguments.
%
%      STAR2('Property','Value',...) creates a new STAR2 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before star2_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to star2_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help star2

% Last Modified by GUIDE v2.5 28-Aug-2022 10:58:40

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @star2_OpeningFcn, ...
                   'gui_OutputFcn',  @star2_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before star2 is made visible.
function star2_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to star2 (see VARARGIN)

% Choose default command line output for star2
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes star2 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = star2_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
selection=questdlg(['ȷ���˳���'],['�˳�ϵͳ'],'��','��','ȡ��');
if strcmp(selection,'��')
    return;
else
    delete(gcf);
end

% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1


% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu3.
function popupmenu3_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu3 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu3


% --- Executes during object creation, after setting all properties.
function popupmenu3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)%�°���
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
star4;
delete(gcbf); 

% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)%Ԥ������
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
star6;
delete(gcbf); 

% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)%ˮ��
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
star5;
delete(gcbf); 

% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Flood20190621=cell2mat(struct2cell(load('Flood20190621.mat')));
Flood20190722=cell2mat(struct2cell(load('Flood20190722.mat')));
Flood20190910=cell2mat(struct2cell(load('Flood20190910.mat')));
Flood20200616=cell2mat(struct2cell(load('Flood20200616.mat')));
Flood20200725=cell2mat(struct2cell(load('Flood20200725.mat')));
Flood20200803=cell2mat(struct2cell(load('Flood20200803.mat')));
Flood20210616=cell2mat(struct2cell(load('Flood20210616.mat')));
Flood20210818=cell2mat(struct2cell(load('Flood20210818.mat')));
Flood20210918=cell2mat(struct2cell(load('Flood20210918.mat')));
opx=cell2mat(struct2cell(load('opx.mat')));
opx1=cell2mat(struct2cell(load('opx1.mat')));
handles.Flood20190621=Flood20190621;
handles.Flood20190722=Flood20190722;
handles.Flood20190910=Flood20190910;
handles.Flood20200616=Flood20200616;
handles.Flood20200725=Flood20200725;
handles.Flood20200803=Flood20200803;
handles.Flood20210616=Flood20210616;
handles.Flood20210818=Flood20210818;
handles.Flood20210918=Flood20210918;
handles.opx=opx;
handles.opx1=opx1;
guidata(hObject,handles);
msgbox('������ɣ�');

% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clear all;
clear handles;
figure( star2);
msgbox('�����������','','warn');

% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global Flood20190621;
Flood20190621=handles.Flood20190621;
guidata(hObject,handles);

global Flood20190722;
Flood20190722=handles.Flood20190722;
guidata(hObject,handles);

global Flood20190910;
Flood20190910=handles.Flood20190910;
guidata(hObject,handles);

global Flood20200616;
Flood20200616=handles.Flood20200616;
guidata(hObject,handles);

global Flood20200725;
Flood20200725=handles.Flood20200725;
guidata(hObject,handles);

global Flood20200803;
Flood20200803=handles.Flood20200803;
guidata(hObject,handles);

global Flood20210616;
Flood20210616=handles.Flood20210616;
guidata(hObject,handles);

global Flood20210818;
Flood20210818=handles.Flood20210818;
guidata(hObject,handles);

global Flood20210918;
Flood20210918=handles.Flood20210918;
guidata(hObject,handles);

global opx1;
opx1=handles.opx1;
guidata(hObject,handles);

global opx;
opx=handles.opx;
guidata(hObject,handles);

msgbox('Ԥ������ɣ�');



% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)%������Ϣ
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
star3;
delete(gcbf); 
