function [gare,result,tt]=TANK_run_rz(xxx)
global Flood20200803;
data1=Flood20200803;
pcp=data1(:,2);
QS=data1(:,4);
global opx1;
xxx=opx1;
tankbegin1=0;
tankbegin2=0;
tankbegin3=0;
    a11=xxx(1);
    a12=xxx(2);
    a13=xxx(3);
    a21=xxx(4);
    a22=xxx(5);
    a31=xxx(6);
    b1=xxx(7);
    b2=xxx(8);
    b3=xxx(9);
    h11=xxx(10);
    h12=xxx(11);
    h13=xxx(12);
    h21=xxx(13);
    h22=xxx(14);
    h31=xxx(15);
QJ=[];
QJJ=[];
e=[];
et=[];
result=[];
bb1=0;
bb2=0;
for i=1:1:length(pcp)
        tankbegin1=tankbegin1+pcp(i);
        tankbegin2=tankbegin2+bb1;
        tankvegin3=tankbegin3+bb2;
        if tankbegin1>h11+h12+h13
            q1=a11*h11+a12*h12+a13*(tankbegin1-h11-h12-h13);
        elseif tankbegin1>h11+h12
            q1=a11*h11+a12*(tankbegin1-h11-h12);
        elseif tankbegin1>h11
            q1=a11*(tankbegin1-h11);
        else
            q1=0;
        end
        bb1=b1*tankbegin1;
        tankbegin1=tankbegin1-q1-bb1;
        if tankbegin2>h21+h22
            q2=a21*h21+a22*(tankbegin2-h21-h22);
        elseif tankbegin2>h21
            q2=a21*(tankbegin2-h21);
        else
            q2=0;
        end
        bb2=b2*tankbegin2;
        tankbegin2=tankbegin2-q2-bb2;
        if tankbegin3>h31
            q3=a31*(tankbegin3-h31);
        else
            q3=0;
        end
        tankbegin3=tankbegin3-q3-b3*tankbegin3;
        q0=(q1+q2+q3)*1311/3.6;
    if i>4
            e(i-4,1)=QS(i-1)-QJ(i-1);
            et(i-4,1)=QS(i-4)-QJ(i-4);
            c = (e.'*e)^ - 1*e.'*et;
            QJJ(i,1)=q0+c*(QS(i-4)-QJ(i-4));
    else
            QJJ(i,1)=q0;
    end
    if  QJJ(i,1)<0
            QJJ(i,1)=q0;
    end
     QJ=[QJ;q0];
end
[hf,fxsj]=max(QJJ,[],1);
[hf2,fxsj2]=max(QS,[],1);
hfpg=abs((hf2-hf)/hf2);
hfpg1=hfpg;
if hfpg>0.2
    hfpg=100;
else
    hfpg=hfpg/0.2;
end  
tt(1)=hfpg1;

fspg=abs(fxsj2-fxsj);
fspg1=fspg;
if fspg>3
    fspg=100;
else
    fspg=fspg/3;
end  
tt(2)=fspg1;

hl=0;
hl2=0;
for n=1:1:length(QJJ)-1
    hl=hl+((QJJ(n)+QJJ(n+1))*3600/2);
    hl2=hl2+((QS(n)+QS(n+1))*3600/2);
end
tt(5)=hl;
tt(6)=hl2;
hlpg=abs((hl2-hl)/hl2);
hlpg1=hlpg;
if hlpg>0.2
    hlpg=100;
else
    hlpg=hlpg/0.2;
end  
tt(3)= hlpg1;
nse=-(1-sum((QJJ-QS).^2)/sum((QS-mean(QS)).^2));
tt(4)= abs(nse);
yy=hlpg+fspg+hfpg+nse;
gare=yy;
tt;
result =[pcp QS QJJ];
end




